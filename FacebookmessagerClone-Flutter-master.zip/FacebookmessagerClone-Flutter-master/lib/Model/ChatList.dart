class Chat {
  final String profileUrl;
  final String username;
  final String userMessage;
  final String timeago;
  final bool seen;

  Chat({this.profileUrl, this.username, this.userMessage, this.timeago, this.seen});

}
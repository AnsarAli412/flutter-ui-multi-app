class Status {
  final String image;

  Status(this.image);
}
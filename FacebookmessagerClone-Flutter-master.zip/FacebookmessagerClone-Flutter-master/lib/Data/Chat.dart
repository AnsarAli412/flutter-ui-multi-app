import 'package:messangerclone_flutter/Model/ChatList.dart';
import 'package:messangerclone_flutter/Model/Status.dart';

List<Chat>  chat = [
  Chat(
    profileUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/3/3c/Chris_Hemsworth_as_Thor.jpg/220px-Chris_Hemsworth_as_Thor.jpg",
    timeago: "2hrs ",
    userMessage: "Hello joan is everything ok",
    username: "Crhus",
    seen: true,
  ),
  Chat(
    profileUrl: "https://ae01.alicdn.com/kf/HTB19Z8zMpXXXXaFaXXXq6xXFXXXf/Marvel-Avengers-Characters-Captain-America-Thor-Action-Figure-Figma-Models-Movie-Fan-Collection-Adult-Gift-Plastic.jpg",
    timeago: "5hrs ",
    userMessage: "Love overloads",
    username: "Louji",
    seen: false,
  ),
  Chat(
    profileUrl: "https://pyxis.nymag.com/v1/imgs/44e/581/197dacaf206831fdb5223da62b58cc3a38-30-avengers-characters.rsquare.w700.jpg",
    timeago: "2 days ",
    userMessage: "Hello joan is everything ok",
    username: "Uganius",
    seen: true,
  ),
  Chat(
    profileUrl: "https://www.hindustantimes.com/rf/image_size_444x250/HT/p2/2020/06/05/Pictures/_d1034a7e-a715-11ea-b9e4-8ce809f9739c.jpg",
    timeago: "2 days ",
    userMessage: "Hello joan is everything ok",
    username: "Crhus",
    seen: false,
  ),
  Chat(
    profileUrl: "https://i.pinimg.com/originals/99/b1/2b/99b12b4652764ce926cd908ec1947842.jpg",
    timeago: "2 days ",
    userMessage: "Hello joan is everything ok",
    username: "Johanna",
    seen: true,
  ),
  Chat(
    profileUrl: "https://www.quirkbooks.com/sites/default/files/u1526/2019/Quirk%20Avengers%202%20Cap%20America.jpg",
    timeago: "24 days ",
    userMessage: "Hello joan is everything ok",
    username: "rion",
    seen: false,
  ),
  Chat(
    profileUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/3/3c/Chris_Hemsworth_as_Thor.jpg/220px-Chris_Hemsworth_as_Thor.jpg",
    timeago: "22 days ",
    userMessage: "Hello joan is everything ok",
    username: "louji",
    seen: false,
  ),
  Chat(
    profileUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/3/3c/Chris_Hemsworth_as_Thor.jpg/220px-Chris_Hemsworth_as_Thor.jpg",
    timeago: "24 days ",
    userMessage: "Hello joan is everything ok",
    username: "Crhus",
    seen: false,
  ),
  Chat(
    profileUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/3/3c/Chris_Hemsworth_as_Thor.jpg/220px-Chris_Hemsworth_as_Thor.jpg",
    timeago: "24 days ",
    userMessage: "Hello joan is everything ok",
    username: "Crhus",
    seen: false,
  ),
  Chat(
    profileUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/3/3c/Chris_Hemsworth_as_Thor.jpg/220px-Chris_Hemsworth_as_Thor.jpg",
    timeago: "2hrs ",
    userMessage: "Hello joan is everything ok",
    username: "Crhus",
    seen: false,
  ),
  Chat(
    profileUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/3/3c/Chris_Hemsworth_as_Thor.jpg/220px-Chris_Hemsworth_as_Thor.jpg",
    timeago: "2hrs ",
    userMessage: "Hello joan is everything ok",
    username: "Crhus",
    seen: false,
  ),
];


List<Status> status = [
  Status("https://i.pinimg.com/originals/99/b1/2b/99b12b4652764ce926cd908ec1947842.jpg"),
  Status("https://i.pinimg.com/originals/99/b1/2b/99b12b4652764ce926cd908ec1947842.jpg"),
  Status("https://i.pinimg.com/originals/99/b1/2b/99b12b4652764ce926cd908ec1947842.jpg"),
  Status("https://i.pinimg.com/originals/99/b1/2b/99b12b4652764ce926cd908ec1947842.jpg"),
  Status("https://i.pinimg.com/originals/99/b1/2b/99b12b4652764ce926cd908ec1947842.jpg"),
  Status("https://i.pinimg.com/originals/99/b1/2b/99b12b4652764ce926cd908ec1947842.jpg"),
];